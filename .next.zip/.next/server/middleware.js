var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__f9e520a4._.js")
R.c("server/chunks/[root-of-the-server]__4b95e4ad._.js")
R.m(27500)
module.exports=R.m(27500).exports
