var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/portofolio/route.js")
R.c("server/chunks/[root-of-the-server]__b2f8e72e._.js")
R.c("server/chunks/eeb45_next_96fd1d2a._.js")
R.c("server/chunks/[root-of-the-server]__6c06ccdf._.js")
R.c("server/chunks/[root-of-the-server]__5ef3c487._.js")
R.c("server/chunks/company-profile__next-internal_server_app_api_portofolio_route_actions_285d8904.js")
R.m(19828)
module.exports=R.m(19828).exports
