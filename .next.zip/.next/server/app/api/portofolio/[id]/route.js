var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/portofolio/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__e59b0096._.js")
R.c("server/chunks/[root-of-the-server]__6c06ccdf._.js")
R.c("server/chunks/[root-of-the-server]__5ef3c487._.js")
R.c("server/chunks/f5839__next-internal_server_app_api_portofolio_[id]_route_actions_7d0279a3.js")
R.m(98658)
module.exports=R.m(98658).exports
