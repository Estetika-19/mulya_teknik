var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/testdb/route.js")
R.c("server/chunks/[root-of-the-server]__094ae1e3._.js")
R.c("server/chunks/[root-of-the-server]__6c06ccdf._.js")
R.c("server/chunks/[root-of-the-server]__5ef3c487._.js")
R.c("server/chunks/company-profile__next-internal_server_app_api_testdb_route_actions_31823859.js")
R.m(50495)
module.exports=R.m(50495).exports
