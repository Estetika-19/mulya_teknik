var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/articles/route.js")
R.c("server/chunks/[root-of-the-server]__bfb85bfa._.js")
R.c("server/chunks/[root-of-the-server]__6c06ccdf._.js")
R.c("server/chunks/[root-of-the-server]__5ef3c487._.js")
R.c("server/chunks/company-profile__next-internal_server_app_api_articles_route_actions_21b2ff28.js")
R.m(72058)
module.exports=R.m(72058).exports
