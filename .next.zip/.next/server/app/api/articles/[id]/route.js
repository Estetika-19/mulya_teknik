var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/articles/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__401fa574._.js")
R.c("server/chunks/[root-of-the-server]__6c06ccdf._.js")
R.c("server/chunks/[root-of-the-server]__5ef3c487._.js")
R.c("server/chunks/f5839__next-internal_server_app_api_articles_[id]_route_actions_e7386f23.js")
R.m(59047)
module.exports=R.m(59047).exports
