var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/check/route.js")
R.c("server/chunks/[root-of-the-server]__47b01a51._.js")
R.c("server/chunks/eeb45_jose_dist_webapi_77f67375._.js")
R.c("server/chunks/[root-of-the-server]__5ef3c487._.js")
R.c("server/chunks/eeb45_next_96fd1d2a._.js")
R.c("server/chunks/company-profile__next-internal_server_app_api_admin_check_route_actions_b5cb34bb.js")
R.m(54132)
module.exports=R.m(54132).exports
