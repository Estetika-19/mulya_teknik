var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/register/route.js")
R.c("server/chunks/[root-of-the-server]__e8cbd776._.js")
R.c("server/chunks/eeb45_bcryptjs_index_d53b94b2.js")
R.c("server/chunks/[root-of-the-server]__5ef3c487._.js")
R.c("server/chunks/[root-of-the-server]__dfb0362f._.js")
R.c("server/chunks/f5839__next-internal_server_app_api_admin_register_route_actions_8644fe83.js")
R.m(55997)
module.exports=R.m(55997).exports
