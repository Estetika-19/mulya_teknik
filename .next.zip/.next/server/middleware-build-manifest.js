globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/a845e85a1741ee15.js",
    "static/chunks/7630603d0a267553.js",
    "static/chunks/1da7204a55ea13db.js",
    "static/chunks/e308975778ac566e.js",
    "static/chunks/248facc1534afa8d.js",
    "static/chunks/turbopack-3693681865ba9f8b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];