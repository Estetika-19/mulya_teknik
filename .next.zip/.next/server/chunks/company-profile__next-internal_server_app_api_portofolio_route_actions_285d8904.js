module.exports=[64867,s=>{"use strict";s.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_api_portofolio_route_actions_285d8904.js.map