module.exports=[23940,s=>{"use strict";s.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_api_admin_check_route_actions_b5cb34bb.js.map