module.exports=[57972,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app__not-found_page_actions_60bf709c.js.map