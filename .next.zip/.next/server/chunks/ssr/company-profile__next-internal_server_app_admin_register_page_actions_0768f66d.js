module.exports=[4082,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_admin_register_page_actions_0768f66d.js.map