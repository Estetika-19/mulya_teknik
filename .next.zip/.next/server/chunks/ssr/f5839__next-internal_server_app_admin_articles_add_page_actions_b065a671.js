module.exports=[5147,a=>{"use strict";a.s([])}];

//# sourceMappingURL=f5839__next-internal_server_app_admin_articles_add_page_actions_b065a671.js.map