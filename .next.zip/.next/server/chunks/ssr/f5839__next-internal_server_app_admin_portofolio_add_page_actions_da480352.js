module.exports=[37786,a=>{"use strict";a.s([])}];

//# sourceMappingURL=f5839__next-internal_server_app_admin_portofolio_add_page_actions_da480352.js.map