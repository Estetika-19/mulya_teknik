module.exports=[24226,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_user_portofolio_page_actions_1170b625.js.map