module.exports=[13930,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_admin_articles_page_actions_5fcca6ab.js.map