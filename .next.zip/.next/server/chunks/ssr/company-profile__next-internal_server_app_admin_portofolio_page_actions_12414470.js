module.exports=[35896,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_admin_portofolio_page_actions_12414470.js.map