module.exports=[90310,a=>{"use strict";a.s([])}];

//# sourceMappingURL=f5839__next-internal_server_app_user_portofolio_%5Bid%5D_page_actions_75d34d39.js.map