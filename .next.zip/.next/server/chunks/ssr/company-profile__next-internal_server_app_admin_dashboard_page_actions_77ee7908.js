module.exports=[94521,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_admin_dashboard_page_actions_77ee7908.js.map