module.exports=[28605,a=>{"use strict";a.s([])}];

//# sourceMappingURL=f5839__next-internal_server_app_admin_portofolio_%5Bid%5D_page_actions_894980ef.js.map