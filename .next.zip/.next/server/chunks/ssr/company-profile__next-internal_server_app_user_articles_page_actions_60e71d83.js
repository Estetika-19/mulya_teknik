module.exports=[80467,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_user_articles_page_actions_60e71d83.js.map