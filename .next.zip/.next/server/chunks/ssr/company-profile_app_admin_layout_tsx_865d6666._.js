module.exports=[4534,a=>{"use strict";var b=a.i(11909);function c({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsx)("body",{className:"bg-gray-100 min-h-screen",children:a})})}a.s(["default",()=>c,"metadata",0,{title:"Admin Panel"}])}];

//# sourceMappingURL=company-profile_app_admin_layout_tsx_865d6666._.js.map