module.exports=[10761,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_admin_login_page_actions_c7984daf.js.map