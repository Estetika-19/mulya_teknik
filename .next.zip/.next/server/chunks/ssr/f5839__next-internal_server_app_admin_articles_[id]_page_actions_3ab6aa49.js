module.exports=[41570,a=>{"use strict";a.s([])}];

//# sourceMappingURL=f5839__next-internal_server_app_admin_articles_%5Bid%5D_page_actions_3ab6aa49.js.map