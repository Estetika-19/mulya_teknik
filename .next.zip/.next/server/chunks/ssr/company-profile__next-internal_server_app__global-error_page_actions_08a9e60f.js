module.exports=[28432,a=>{"use strict";a.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app__global-error_page_actions_08a9e60f.js.map