module.exports=[57604,s=>{"use strict";s.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_api_articles_route_actions_21b2ff28.js.map