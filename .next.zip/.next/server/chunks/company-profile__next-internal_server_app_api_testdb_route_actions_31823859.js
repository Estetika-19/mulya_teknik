module.exports=[36703,s=>{"use strict";s.s([])}];

//# sourceMappingURL=company-profile__next-internal_server_app_api_testdb_route_actions_31823859.js.map