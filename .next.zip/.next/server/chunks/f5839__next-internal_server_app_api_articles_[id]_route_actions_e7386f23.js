module.exports=[62811,s=>{"use strict";s.s([])}];

//# sourceMappingURL=f5839__next-internal_server_app_api_articles_%5Bid%5D_route_actions_e7386f23.js.map