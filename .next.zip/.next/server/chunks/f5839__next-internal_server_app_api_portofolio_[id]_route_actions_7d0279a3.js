module.exports=[33973,s=>{"use strict";s.s([])}];

//# sourceMappingURL=f5839__next-internal_server_app_api_portofolio_%5Bid%5D_route_actions_7d0279a3.js.map